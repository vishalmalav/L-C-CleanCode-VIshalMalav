namespace UnitTest;

public class UnitTest
{
    public int GetDivisorCount(int input)
    {
        throw new NotImplementedException();
    }
}