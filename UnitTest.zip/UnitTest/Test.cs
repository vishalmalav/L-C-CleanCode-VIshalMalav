namespace UnitTest;

public class Test
{
    [Theory]
    [InlineData(3, 1)]
    [InlineData(15, 2)]
    [InlineData(100, 15)]
    public void GetDivisorCountWithExpectedOutput(int input, int expected)
    {
        var test = new UnitTest();

        var output = test.GetDivisorCount(input);

        Assert.Equal(output, expected);
    }

    [Theory]
    [InlineData(3, 2)]
    [InlineData(15, 5)]
    [InlineData(100, 6)]
    public void GetDivisorCountWithInvalidOutput(int input, int expected)
    {
        var test = new UnitTest();

        var output = test.GetDivisorCount(input);

        Assert.NotEqual(output, expected);
    }

    [Theory]
    [InlineData(-500)]
    [InlineData(0.99)]
    [InlineData(-99)]
    public void GetDivisorCountWithInvalidInput(int input)
    {
        var test = new UnitTest();

        Assert.Throws<ArgumentException>(() => test.GetDivisorCount(input));
    }
}